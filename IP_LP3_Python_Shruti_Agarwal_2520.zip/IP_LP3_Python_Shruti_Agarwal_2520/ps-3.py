'''Coding Question:3
    You are given n-words. Some words may repeat. For each word, output its number of
occurrences. The output order should correspond with the input order of the
appearance of the word. See the sample input/output for clarification.'''

n = int(input())
words = list()
a = dict()
count = 0

for i in range(n):
    words.append(input())

for word in words:
    a[word] = a.get(word, 0) + 1

print(len(a))
for key, value in a.items():
    print(a[key], end=" ")