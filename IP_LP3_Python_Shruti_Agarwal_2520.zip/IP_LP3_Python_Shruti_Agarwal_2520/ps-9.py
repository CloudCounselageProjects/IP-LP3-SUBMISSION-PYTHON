'''Coding Question:
Write a Python program to calculate the sum of the positive integers of n+(n-2)+(n-4)...
(until n-x =< 0).'''

def sum_series(n):
    sum = 0

    for i in range(n):
        x = n - 2*i
        if x <= 0:
            break
        else:
            sum = sum + x

    return sum

num = int(input())
res = sum_series(num)
print(res)