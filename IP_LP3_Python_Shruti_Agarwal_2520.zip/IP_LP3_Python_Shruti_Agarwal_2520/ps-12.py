'''Coding Question:
Write a Python program to get a week number.
Sample Date :
2015, 6, 16
Expected Output :
25'''

import datetime

yr = int(input("Enter year: "))
mon = int(input("Enter month: "))
day = int(input("Enter day: "))

x = datetime.datetime(yr,mon,day)

print(int(x.strftime("%W"))+1)
