'''Coding Question:
Write a Python program to convert temperatures to and from celsius, Fahrenheit.
[ Formula : c/5 = f-32/9 [ where c = temperature in celsius and f = temperature in
Fahrenheit ]
Expected Output :
60°C is 140 in Fahrenheit
45°F is 7 in Celsius'''

c = 60
f = 45
conv_f = int((9 * (c / 5)) + 32)
conv_c = int(((f - 32) / 9) * 5)

print(str(c)+"\u00b0C is", conv_f, "in Fahrenheit")
print(str(f)+"\u00b0F is", conv_c, "in Celsius")