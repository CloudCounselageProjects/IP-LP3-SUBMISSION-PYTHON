'''Coding Question:5
You have given a string. You need to remove all the duplicates from the string.
The final output string should contain each character only once. The respective order of
the characters inside the string should remain the same. You can only traverse the
string at once.'''

word = input()
newWord = str()

for i in word:
    if i not in newWord:
        newWord = newWord + i
    else:
        continue

print(newWord)