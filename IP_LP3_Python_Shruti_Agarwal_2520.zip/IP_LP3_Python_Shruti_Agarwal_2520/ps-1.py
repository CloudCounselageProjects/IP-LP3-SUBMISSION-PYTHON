a = int(input("Enter first integer: "))
b = int(input("Enter second integer: "))

print("Sum: ", a + b)
print("Difference", a - b)
print("Product", a * b)