'''Coding question:1
    Read two integers from STDIN and print three lines where:
● The first line contains the sum of the two numbers.
● The second line contains the difference between the two numbers (first -
second).
● The third line contains the product of the two numbers.'''

a = int(input("Enter first integer: "))
b = int(input("Enter second integer: "))

print("Sum: ", a + b)
print("Difference", a - b)
print("Product", a * b)