'''Coding Question:
Write a Python program to find the first appearance of the substring 'not' and 'poor' from
a given string, if 'not' follows the 'poor', replace the whole 'not'...' poor' substring with
'good'. Return the resulting string.
Sample String :
'The lyrics is not that poor!'
'The lyrics is poor!'
Expected Result :
'The lyrics is good!'
'The lyrics is poor!'
'''

num = int(input("Enter no of lines: "))
Lines = list()

for i in range(num):
    Lines.append(input())

for Line in Lines:
    if 'not' in Line:
        if 'poor' in Line:
            if 'poor' > 'not':
                print(Line.replace("not that poor", "good"))
            else:
                print(Line)
        else:
            print(Line)
    else:
        print(Line)