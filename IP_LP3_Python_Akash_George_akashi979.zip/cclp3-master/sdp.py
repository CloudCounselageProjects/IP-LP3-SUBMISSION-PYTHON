n1 = int(input('Enter a number: '))
n2 = int(input('Enter another number:'))
if 1<=n1<=10**10 and 1<=n2<=10**10:
 addition = n1+n2
 diff = n1-n2
 prod = n1*n2
 print (addition)                              
 print (diff)                       
 print (prod) 
  
